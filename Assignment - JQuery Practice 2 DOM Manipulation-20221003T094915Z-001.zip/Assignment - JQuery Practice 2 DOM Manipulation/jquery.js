

$(document).ready(function(){
    

function converter(){
    var base = $(".base").val();
    var value = $(".toinput").val();

    if(value==""|| base==""){
        alert("please input the required numbers!!")
    }else{
    var firstresult= parseInt(value,base);
    var result = parseInt(firstresult,10);
    $('.answer').val(result)}
 

}
function monthIdentifier(){
    const month = ["January","February","March","April","May","June","July","August","September","October","November","December"];

    var D = new Date($(".date").val());
    if(D=="Invalid Date"){
        alert("Please input a Date");
    }else{ let name = month[D.getMonth()];

        $(".revealmonth").val(name)}
   
}
function dayIdentifier(){
    var m = new Date($(".day").val());
    if(m=="Invalid Date"){
        alert("please put valid Date!!")
    } else{ 
        let day = m.getDay();
    
        if(day>5){
            day = "Weekend"
            $(".revealday").val(day)
        }else{
            day = "Weekday"
            $(".revealday").val(day)
        }}  

}
$('.convert').click(function(){
    
    converter();
 })
 $(".monthbtn").click(function(){
    
     monthIdentifier();
 })
 $(".daybtn").click(function(){
   
 
     dayIdentifier();
 
    
 })
})