
package simplecalculator.java;

import java.util.Scanner;

public class Addition extends Calculator{
   
    void equals(){
        Scanner sum = new Scanner(System.in);
        System.out.println();
        System.out.print("Enter first Number: ");
        int x = sum.nextInt();
        
        System.out.print("Enter second Number: ");
        int y = sum.nextInt();
        
        
        int add = x + y;
        System.out.println("Equivalence: " + x + " + " + y + " = " + add);
        
    }
}

