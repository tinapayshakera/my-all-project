package simplecalculator.java;

public class Calculator {

    void equals() {
        System.out.println("This is a simple calculator.");
    }
}
