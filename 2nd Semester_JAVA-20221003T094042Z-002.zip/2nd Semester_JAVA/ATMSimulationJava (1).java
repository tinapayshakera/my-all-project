package atm.simulation.java;

import java.util.Scanner;

public class ATMSimulationJava {

    public static void main(String[] args) {
        int balance = 10000, withdraw, deposit;
        Scanner s = new Scanner(System.in);
        while (true) {
            System.out.println("Automated Bank Teller");
            System.out.println("A. for Balance Inquiry");
            System.out.println("B. for Withdraw");
            System.out.println("C. for Deposite");
            System.out.println("D. for EXIT");
            System.out.print("Type the operation you want:");
         char bank = s.next().charAt(0);
            switch (bank) {
                case 'A':
                    System.out.println("Balance : " + balance);
                    System.out.println("");
                    break;

                case 'B':
                    System.out.print("Enter money to be withdrawn:");
                    withdraw = s.nextInt();
                    if (balance >= withdraw) {
                        balance = balance - withdraw;
                        System.out.println("Please gather your money");
                    } else {
                        System.out.println("Insufficient Balance");
                    }
                    System.out.println("");
                    break;
                case 'C':
                    System.out.print("Enter money to be deposited:");
                    deposit = s.nextInt();
                    balance = balance + deposit;
                    System.out.println("Your Money has been successfully depsited");
                    System.out.println("");
                    break;

                case 'D':
                    System.exit(0);
            }
        }
    }
}
