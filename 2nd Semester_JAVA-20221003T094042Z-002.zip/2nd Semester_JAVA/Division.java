package calculatorpolymorphism.java;

public class Division extends Calculator {

    @Override
    public void equals(int x, int y) {
            System.out.println("This is the qoutient : ");
            System.out.println(x / y);
    }

}
