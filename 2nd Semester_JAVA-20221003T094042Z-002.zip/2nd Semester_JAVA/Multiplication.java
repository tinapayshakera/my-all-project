package calculatorpolymorphism.java;

public class Multiplication extends Calculator {

   @Override
    public void equals(int x, int y) {
            System.out.println("This is the product : ");
            System.out.println(x * y);

    }

}
