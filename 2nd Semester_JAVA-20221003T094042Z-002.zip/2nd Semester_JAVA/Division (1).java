package simplecalculator.java;

import java.util.Scanner;

public class Division extends Calculator {

    void equals() {
        Scanner quotient = new Scanner(System.in);

        System.out.print("Enter first Number: ");
        double x = quotient.nextDouble();

        System.out.print("Enter second Number: ");
        double y = quotient.nextDouble();

        double divide = x / y;
        System.out.println("Equivalence: " + x + " Ã· " + y + " = " + divide);

    }

}
