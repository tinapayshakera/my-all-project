package simplecalculator.java;

import java.util.Scanner;

public class Subtraction extends Calculator {

    void equals() {
        Scanner diff = new Scanner(System.in);
        System.out.println();
        System.out.print("Enter first Number: ");
        int x = diff.nextInt();

        System.out.print("Enter second Number: ");
        int y = diff.nextInt();

        int subtract = x - y;
        System.out.println("Equivalence: " + x + " - " + y + " = " + subtract);

    }
}
