package calculatorpolymorphism.java;

public class Addition extends Calculator {

    @Override
    public void equals(int x, int y) {
            System.out.println("This is the sum : ");
            System.out.println(x + y);
        
    }
}
