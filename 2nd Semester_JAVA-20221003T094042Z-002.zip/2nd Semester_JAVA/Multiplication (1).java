package simplecalculator.java;

import java.util.Scanner;

public class Multiplication extends Calculator {

    void equals() {
        Scanner product = new Scanner(System.in);
        System.out.println();
        System.out.print("Enter first Number: ");
        int x = product.nextInt();

        System.out.print("Enter second Number: ");
        int y = product.nextInt();

        int multiply = x * y;
        System.out.println("Equivalence: " + x + " * " + y + " = " + multiply);

    }

}
