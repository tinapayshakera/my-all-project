
package calculatorpolymorphism.java;


public class Calculator {
     public void equals(int x, int y) {
        System.out.println("This is a simple calculator. We are to calculate the numbers : ");
         System.out.println(x);
         System.out.println(y);
    }
}