package tinapayjavaexercise3;

import java.util.Scanner;

public class TinapayJavaExercise3 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int num = scanner.nextInt();

        for (int startNum = 0; startNum < num + 1; startNum++) {

            if (startNum % 2 == 0) {
                System.out.println(startNum + " (even)");
            } else {
                System.out.println(startNum + " (odd)");
            }
        }

    }

}
