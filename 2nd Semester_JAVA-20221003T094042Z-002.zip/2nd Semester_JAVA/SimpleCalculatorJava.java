package simplecalculator.java;

import java.util.Scanner;

public class SimpleCalculatorJava {

    public static void main(String[] args) {

        Scanner choose = new Scanner(System.in);

        while (true) {
            System.out.println();
            System.out.println("Please enter operation");
            System.out.println("1. Addition ");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Division");
            System.out.println();
            System.out.println("Enter chosen number::");

            int choice = choose.nextInt();

            switch (choice) {

                case 1:
                    Calculator add = new Addition();
                    add.equals();
                    System.out.println();
                    System.out.println("Calculation completed!");
                    break;
                case 2:
                    Calculator subtract = new Subtraction();
                    subtract.equals();
                    System.out.println();
                    System.out.println("Calculation completed!");
                    break;
                case 3:
                    Calculator multiply = new Multiplication();
                    multiply.equals();
                    System.out.println();
                    System.out.println("Calculation completed!");
                    break;
                case 4:
                    Calculator divide = new Division();
                    divide.equals();
                    System.out.println();

                    System.out.println("Calculation completed!");
                    break;
                default:
                    Calculator basic = new Calculator();
                    basic.equals();

            }

        }

    }
}
