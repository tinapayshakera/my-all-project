package calculatorpolymorphism.java;

import java.util.Scanner;

public class Subtraction extends Calculator {
    @Override
    public void equals(int x, int y) {
            System.out.println("This is the difference : ");
            System.out.println(x - y);
    }
}
