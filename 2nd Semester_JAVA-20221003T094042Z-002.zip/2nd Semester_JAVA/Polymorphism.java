
package calculatorpolymorphism.java;


public class Polymorphism {
    public static void main(String[] args) {
        Calculator c = new Calculator();
        c.equals(23,21);
        Calculator a = new Addition();
        a.equals(23,21);
        Calculator s = new Subtraction();
        s.equals(23,21);
        Calculator m = new Multiplication();
        m.equals(23,21);
        Calculator d = new Division();
        d.equals(23,21);
    }
}
