
package tinapayjavasimplecalculator;
import java.util.Scanner;
public class TinapayJavaSimpleCalculator {

	static int result;
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		
		while(true){
                        
                        System.out.println("Please enter operation");
                        System.out.println("1. Addition ");
                        System.out.println("2. Subtraction");
                        System.out.println("3. Multiplication");
			
			System.out.println();
			System.out.println("Enter choice::");
			int choice = scan.nextInt();
                        
                        System.out.println();
			System.out.println("Enter first number::");
			int firstNumber = scan.nextInt();
			System.out.println("Enter second number::");
			int secondNumber = scan.nextInt();

			switch(choice){
			case 1: 
                            System.out.println("The answer is : ");
                            System.out.println(firstNumber + secondNumber);
			break;
			case 2: 
                            System.out.println("The answer is : ");
                            System.out.println(firstNumber - secondNumber);
			break;
			case 3: 
                            System.out.println("The answer is : ");
                            System.out.println(firstNumber * secondNumber);
                            
			break;
			default: System.out.println("Incorrect input!!! Please re-enter choice from our menu");
                        }
                }
        }}

                


	