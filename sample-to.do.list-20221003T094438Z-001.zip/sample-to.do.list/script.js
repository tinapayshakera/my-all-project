var limit = 6
var currentAmount = 3;
var ol = document.getElementById("list");

function list(item) {

  //Check we haven't reached our limit.
  if (currentAmount < limit) {
    var li = document.createElement("li");
    var str = document.createTextNode(item);
    var btn = document.createElement('button');
    li.appendChild(str);
    li.appendChild(btn);
    li.classList.add('item');
    btn.classList.add('del');
    ol.appendChild(li);
    currentAmount++; //Increment our count
  }
  return false;
}

ol.addEventListener('click', function(event) {
  if (event.target != event.curentTarget) {
    var tgt = event.target;
    var li = tgt.parentElement;
    ol.removeChild(li);
    currentAmount--;
  }
  event.stopPropagation();
}, false);